<?php
namespace OCA\ScheduledSharing\Service;

use Exception;

class ServiceException extends Exception {}