<?php
namespace OCA\ScheduledSharing\Service;

class NotFoundException extends ServiceException {}