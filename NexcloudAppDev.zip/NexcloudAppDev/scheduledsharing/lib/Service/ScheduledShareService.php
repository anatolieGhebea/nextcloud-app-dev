<?php 

namespace OCA\ScheduledSharing\Service;

use Exception;

use OCP\AppFramework\Db\DoesNotExistException;
use OCP\AppFramework\Db\MultipleObjectsReturnedException;
use OCP\Files\NotFoundException;

use OCA\ScheduledSharing\Db\ScheduledShare;
use OCA\ScheduledSharing\Db\ScheduledShareMapper;

class ScheduledShareService {

    private $shareMapper;

    public function __construct(ScheduledShareMapper $shareMapper)
    {
        $this->shareMapper = $shareMapper;
    }

    public function findAll($userId)
    {
        return $this->shareMapper->findAll($userId);
    }


    public function find(int $id, string $userId) {
        try {
            return $this->shareMapper->find($id, $userId);
        } catch(Exception $e) {
            $this->handleException($e);
        }
    }

    /**
     * @param string $path
	 * @param int $permissions
	 * @param int $shareType
	 * @param string $shareWith
	 * @param string $publicUpload
	 * @param string $password
	 * @param string $sendPasswordByTalk
	 * @param string $expireDate
	 * @param string $label
	 *
	 * @return DataResponse
	 * @throws NotFoundException
     * 
     */
    public function create(
        string $path = null,
        int $permissions = null,
        int $shareType = -1,
        string $shareWith = null,
        string $publicUpload = 'false',
        string $password = '',
        string $sendPasswordByTalk = null,
        string $expireDate = '',
        string $label = '') 
    {
        $scShare = new ScheduledShare();
		$scShare->setPath($path);
		$scShare->setPermissions($permissions);
		$scShare->setShareType($shareType);
		$scShare->setShareWith($shareWith);
		$scShare->setPublicUpload($publicUpload);
		$scShare->setPassword($password);
		$scShare->setSendPasswordByTalk($sendPasswordByTalk);
		$scShare->seTexpireDate($expireDate);
        $scShare->setLabel($label);
        
        return $this->shareMapper->insert($scShare);
    }

    	/**
	 * @NoAdminRequired
	 *
	 * @param string $id
	 * @param int $permissions
	 * @param string $password
	 * @param string $sendPasswordByTalk
	 * @param string $publicUpload
	 * @param string $expireDate
	 * @param string $note
	 * @param string $label
	 * @param string $hideDownload
	 * @return DataResponse
	 * @throws NotFoundException
	 */
	public function update(
		string $id,
		int $permissions = null,
		string $password = null,
		string $sendPasswordByTalk = null,
		string $publicUpload = null,
		string $expireDate = null,
		string $note = null,
		string $label = null,
		string $hideDownload = null)
    {
        try {
            $scShare = $this->find($id, $this->userId);
            
            $scShare->setPermissions($permissions);
            $scShare->setPublicUpload($publicUpload);
            $scShare->setPassword($password);
            $scShare->setSendPasswordByTalk($sendPasswordByTalk);
            $scShare->seTexpireDate($expireDate);
            $scShare->setLabel($label);

            return $this->shareMapper->update($scShare);
		} catch(Exception $e) {
			$this->handleException($e);
        }
    }

    /**
     * @param string $id
     */
    public function delete(string $id)
    {
        try {
            $scShare = $this->find($id, $this->userId);
            $this->shareMapper->delete($scShare);
            return $scShare;
		} catch(Exception $e) {
			$this->handleException($e);
		}
    }


    // 
    // PRIVATE METHODS
    // 

    // in order to be able to plug in different storage backends like files
    // for instance it is a good idea to turn storage related exceptions
    // into service related exceptions so controllers and service users
    // have to deal with only one type of exception
    private function handleException ($e) {
        if ($e instanceof DoesNotExistException ||
            $e instanceof MultipleObjectsReturnedException) {
            throw new NotFoundException($e->getMessage());
        } else {
            throw $e;
        }
    }

}