<?php
namespace OCA\ScheduledSharing\Controller;

use OCP\IRequest;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\AppFramework\Http\DataResponse;
// use OCP\AppFramework\Controller;
use OCP\AppFramework\ApiController;

use OCA\Files_Sharing\Exceptions\SharingRightsException;
use OCA\Files_Sharing\External\Storage;
use OCA\Files\Helper;
use OCP\AppFramework\OCS\OCSBadRequestException;
use OCP\AppFramework\OCS\OCSException;
use OCP\AppFramework\OCS\OCSForbiddenException;
use OCP\AppFramework\OCS\OCSNotFoundException;
use OCP\AppFramework\OCSController;
use OCP\AppFramework\QueryException;
use OCP\Constants;
use OCP\Files\InvalidPathException;
use OCP\Files\IRootFolder;
use OCP\Files\Folder;
use OCP\Files\Node;
use OCP\Files\NotFoundException;
use OCP\IL10N;
use OCP\Share\Exceptions\ShareNotFound;

use OCA\ScheduledSharing\Service\ScheduledShareService;


class ScheduledShareAPIController extends ApiController {

	private $userId;
	private $scShareService;

	use Errors;

	public function __construct($AppName, IRequest $request, ScheduledShareService $scShareService, $UserId){
		parent::__construct($AppName, $request);
		$this->userId = $UserId;
		$this->scShareService = $scShareService;
	}


	/**
	 * The getShares function.
	 * @CORS
     * @NoCSRFRequired
	 * @NoAdminRequired
	 *
	 * - Get schduled shares by the current user
	 * 
	 * @return DataResponse
	 * @throws NotFoundException
	 * 
	 */
	public function index(): DataResponse { 
		return new DataResponse($this->scShareService->findAll($this->userId));
	}


		/**
	 * Get a specific share by id, if it's belonging to the current user
	 *
	 * @CORS
     * @NoCSRFRequired
	 * @NoAdminRequired
	 *
	 * @param string $id
	 * @return DataResponse
	 * @throws NotFoundException
	 */
	public function show(string $id): DataResponse {
		return $this->handleNotFound( function() use ($id) {
			return $this->scShareService->find($id, $this->userId);
		});
	}



	/**
	 * @CORS
     * @NoCSRFRequired
	 * @NoAdminRequired
	 *
	 * @param string $path
	 * @param int $permissions
	 * @param int $shareType
	 * @param string $shareWith
	 * @param string $publicUpload
	 * @param string $password
	 * @param string $sendPasswordByTalk
	 * @param string $expireDate
	 * @param string $label
	 *
	 */
	public function create(
		string $path = null,
		int $permissions = null,
		int $shareType = -1,
		string $shareWith = null,
		string $publicUpload = 'false',
		string $password = '',
		string $sendPasswordByTalk = null,
		string $expireDate = '',
		string $label = ''
	) 
	{

		return $this->scShareService->create( $path, $permissions, $shareType, $shareWith, $publicUpload, $password, $sendPasswordByTalk, $expireDate, $label );
	}


	/**
	 * @CORS
     * @NoCSRFRequired
	 * @NoAdminRequired
	 *
	 * @param string $id
	 * @param int $permissions
	 * @param string $password
	 * @param string $sendPasswordByTalk
	 * @param string $publicUpload
	 * @param string $expireDate
	 * @param string $note
	 * @param string $label
	 * @param string $hideDownload
	 */
	public function update(
		string $id,
		int $permissions = null,
		string $password = null,
		string $sendPasswordByTalk = null,
		string $publicUpload = null,
		string $expireDate = null,
		string $note = null,
		string $label = null,
		string $hideDownload = null
	) {

		return $this->handleNotFound(function () use ($id, $permissions, $password, $sendPasswordByTalk, $publicUpload, $expireDate, $note, $label, $hideDownload ) {
			return $this->scShareService->update($id, $permissions, $password, $sendPasswordByTalk, $publicUpload, $expireDate, $note, $label, $hideDownload );
		});
		
	}

	/**
	 * Delete a share
	 *
	 * @CORS
     * @NoCSRFRequired
	 * @NoAdminRequired
	 *
	 * @param string $id
	 * @return DataResponse
	 * @throws OCSNotFoundException
	 */
	public function destroy(string $id): DataResponse {
		return $this->handleNotFound(function() use ($id) {
			return $this->scShareService->delete($id);
		});
	}
}
