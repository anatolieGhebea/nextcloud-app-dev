<?php
namespace OCA\ScheduledSharing\Db;

use JsonSerializable;

use OCP\AppFramework\Db\Entity;

class ScheduledShare extends Entity implements JsonSerializable {

    protected $id;
    protected $share_type;
    protected $share_with;
    protected $password;
    protected $uid_owner;
    protected $uid_initiator;
    protected $parent;
    protected $item_type;
    protected $item_source;
    protected $item_target;
    protected $file_source;
    protected $file_target;
    protected $permissions;
    protected $stime;
    protected $accepted;
    protected $share_availabel_from;
    protected $mail_send;
    protected $share_name;

    public function __construct() {
        $this->addType('id','integer');
    }

    public function jsonSerialize() {
        return [
            'id' => $this->id,
            'share_type' => $this->share_type,
            'share_with' => $this->share_with,
            'password' => $this->password,
            'uid_owner' => $this->uid_owner,
            'uid_initiator' => $this->uid_initiator,
            'parent' => $this->parent,
            'item_type' => $this->item_type,
            'item_source' => $this->item_source,
            'item_target' => $this->item_target,
            'file_source' => $this->file_source,
            'file_target' => $this->file_target,
            'permissions' => $this->permissions,
            'stime' => $this->stime,
            'accepted' => $this->accepted,
            'share_availabel_from' => $this->share_availabel_from,
            'mail_send' => $this->mail_send,
            'share_name' => $this->share_name
        ];
    }
}
