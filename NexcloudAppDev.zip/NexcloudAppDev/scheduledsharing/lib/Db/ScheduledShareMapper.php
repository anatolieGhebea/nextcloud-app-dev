<?php
namespace OCA\ScheduledSharing\Db;

use OCP\IDBConnection;
use OCP\AppFramework\Db\QBMapper;

class ScheduledShareMapper extends QBMapper {

    public function __construct(IDBConnection $db) {
        parent::__construct($db, 'scheduledsharing_scheduled_share', Note::class);
    }

    public function find(int $id, string $userId) {
        $qb = $this->db->getQueryBuilder();

                    $qb->select('*')
                             ->from($this->getTableName())
                             ->where(
                                     $qb->expr()->eq('id', $qb->createNamedParameter($id))
                             )->andWhere(
                                $qb->expr()->eq('uid_owner', $qb->createNamedParameter($userId)) 
                            );

        return $this->findEntity($qb);
    }

    public function findAll(string $userId) {
        $qb = $this->db->getQueryBuilder();

        $qb->select('*')
           ->from($this->getTableName())
           ->where(
            $qb->expr()->eq('uid_owner', $qb->createNamedParameter($userId))
           );

        return $this->findEntities($qb);
    }

}