// const webpackConfig = require('@nextcloud/webpack-vue-config')

// module.exports = webpackConfig

const path = require('path');

module.exports = {
	entry: {
		'main': path.join(__dirname, 'src', 'main.js')
	},
	output: {
		path: path.resolve(__dirname, './js/dist/'),
		publicPath: '/js/',
		filename: '[name].js',
		chunkFilename: 'scheduledsharing.[id].js?v=[chunkhash]',
		jsonpFunction: 'webpackJsonpFilesSharing'
	}
}