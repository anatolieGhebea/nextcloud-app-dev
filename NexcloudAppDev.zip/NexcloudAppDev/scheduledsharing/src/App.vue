<template>
	<div id="content" class="app-scheduledsharing">
		does render
	</div>
</template>

<script>
export default {
	name: 'App',
	data() {
		return {
			notes: [],
			currentNoteId: null,
			updating: false,
			loading: true,
		}
	},
	computed: {},
	/**
	 * Fetch list of notes when the component is loaded
	 */
	async mounted() {
		this.debug('mounted')
	},
	methods: {
		debug(cnt) {
			/* eslint-disable no-console */
			console.log(cnt)
			/* eslint-enable no-console */
		},
	},
}
</script>
<style scoped>
	#app-content > div {
		width: 100%;
		height: 100%;
		padding: 20px;
		display: flex;
		flex-direction: column;
		flex-grow: 1;
	}
	input[type='text'] {
		width: 100%;
	}
	textarea {
		flex-grow: 1;
		width: 100%;
	}
</style>
