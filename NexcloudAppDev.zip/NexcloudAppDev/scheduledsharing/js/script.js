console.log('start fetch');
fetch('http://localhost:8085/index.php/apps/scheduledsharing/api/v1/scheduledshares', {
        method: 'GET', // or 'PUT'
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => {
        console.log(response);
        response.json();
    })
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error);
    });