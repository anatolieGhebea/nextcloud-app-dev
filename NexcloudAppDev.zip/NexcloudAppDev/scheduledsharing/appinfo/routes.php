<?php
/**
 * Create your routes in here. The name is the lowercase name of the controller
 * without the controller part, the stuff after the hash is the method.
 * e.g. page#index -> OCA\ScheduledSharing\Controller\PageController->index()
 *
 * The controller class has to be registered in the application.php file since
 * it's instantiated in there
 */
return [
	'resource' => [
		'scheduled_sharing_api' => ['url' => '/api/v1.0/notes']
	],
    'routes' => [
		['name' => 'page#index', 'url' => '/', 'verb' => 'GET'],
		['name' => 'page#do_echo', 'url' => '/echo', 'verb' => 'POST'],
		['name' => 'page#do_echo', 'url' => '/echo', 'verb' => 'POST'],
		// [
		// 	'name' => 'ScheduledShareAPI#getShares',
		// 	'url'  => '/api/v1/scheduledshares',
		// 	'verb' => 'GET',
		// ],
		[
			'name' => 	'scheduled_sharing_api#preflighted_cors', 
						'url' => '/api/v1.0/{path}',
						'verb' => 'OPTIONS', 
						'requirements' => ['path' => '.+']
		]
    ],

    'ocs' => [
		/*
		 * OCS Share API
		 */
		[
			'name' => 'ScheduledShareAPI#getShares',
			'url'  => '/api/v1/scheduledshares',
			'verb' => 'GET',
		],
		// [
		// 	'name' => 'ScheduledShareAPI#getInheritedShares',
		// 	'url'  => '/api/v1/scheduledshares/inherited',
		// 	'verb' => 'GET',
		// ],
		[
			'name' => 'ScheduledShareAPI#createShare',
			'url'  => '/api/v1/scheduledshares',
			'verb' => 'POST',
		],
		[
			'name' => 'ScheduledShareAPI#getShare',
			'url'  => '/api/v1/scheduledshares/{id}',
			'verb' => 'GET',
		],
		[
			'name' => 'ScheduledShareAPI#updateShare',
			'url'  => '/api/v1/scheduledshares/{id}',
			'verb' => 'PUT',
		],
		[
			'name' => 'ScheduledShareAPI#deleteShare',
			'url'  => '/api/v1/scheduledshares/{id}',
			'verb' => 'DELETE',
		],
		
		/*
		 * Deleted Shares
		 */
		// [
		// 	'name' => 'DeletedShareAPI#index',
		// 	'url'  => '/api/v1/deletedshares',
		// 	'verb' => 'GET',
		// ],
		// [
		// 	'name' => 'DeletedShareAPI#undelete',
		// 	'url'  => '/api/v1/deletedshares/{id}',
		// 	'verb' => 'POST',
		// ],

		/*
		 * Remote Shares
		 */
		// [
		// 	'name' => 'Remote#getShares',
		// 	'url' => '/api/v1/remote_shares',
		// 	'verb' => 'GET',
		// ],
		// [
		// 	'name' => 'Remote#getOpenShares',
		// 	'url' => '/api/v1/remote_shares/pending',
		// 	'verb' => 'GET',
		// ],
		// [
		// 	'name' => 'Remote#acceptShare',
		// 	'url' => '/api/v1/remote_shares/pending/{id}',
		// 	'verb' => 'POST',
		// ],
		// [
		// 	'name' => 'Remote#declineShare',
		// 	'url' => '/api/v1/remote_shares/pending/{id}',
		// 	'verb' => 'DELETE',
		// ],
		// [
		// 	'name' => 'Remote#getShare',
		// 	'url' => '/api/v1/remote_shares/{id}',
		// 	'verb' => 'GET',
		// ],
		// [
		// 	'name' => 'Remote#unshare',
		// 	'url' => '/api/v1/remote_shares/{id}',
		// 	'verb' => 'DELETE',
		// ],
	],
];
